# This file makes the 'sckm' directory a Python package.
